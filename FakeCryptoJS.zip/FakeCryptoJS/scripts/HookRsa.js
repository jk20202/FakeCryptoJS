(function () {
    const originalCharCodeAt = String.prototype.charCodeAt;
    String.prototype.charCodeAt = function (a) {
        if (this.length == 256 && a == 255) {
            const stack = new Error().stack;
            const stackLines = stack.split("\n");
            window.vlog("[FakeCryptoJS]=>" + "rsa: \n" + stackLines.filter((_, i) => i > 2).join('\n'));
        }
        return originalCharCodeAt.apply(this, arguments);
    };
})()